create trigger TRI_T_TASK_AUTO
  before insert
  on T_TASK
  for each row
  begin
    select seq_task.nextval into :new.task_id from dual;
  end;
/

