create trigger TRI_T_EMPLOYEE_AUTO
  before insert
  on T_EMPLOYEE
  for each row
  begin
    select seq_employee.nextval into :new.employee_id from dual;
  end;
/

