create trigger TRI_T_PLAN_AUTO
  before insert
  on T_PLAN
  for each row
  begin
    select seq_plan.nextval into :new.plan_id from dual;
  end;
/

